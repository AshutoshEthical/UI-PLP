package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.AdminDAO;
import com.sun.jndi.ldap.Connection;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter writer = response.getWriter();

		String username = request.getParameter("uname");
		String password = request.getParameter("pass");

		writer.println("<html><body>");

		RequestDispatcher dispatcher = null;

		if (AdminDAO.validate(username, password).equals("adm")) {

			dispatcher = request.getRequestDispatcher("admin");
			dispatcher.forward(request, response);
		} else if (AdminDAO.validate(username, password).equals("usr")) {

			dispatcher = request.getRequestDispatcher("user");
			dispatcher.forward(request, response);
		} else if (AdminDAO.validate(username, password).equals("agnt")) {

			dispatcher = request.getRequestDispatcher("agent");
			dispatcher.forward(request, response);
		}

		else {

			writer.println("<h1><font color ='red'>Invalid credentials,Try again</font></h1> ");
			dispatcher = request.getRequestDispatcher("login.html");
			dispatcher.include(request, response);
		}

		writer.println("</html></body>");
	}
}
