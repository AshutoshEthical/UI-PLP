package com.cg.exception;

public class EMSException extends Exception{

		public EMSException(String Message) {
			super(Message);
		}
}
